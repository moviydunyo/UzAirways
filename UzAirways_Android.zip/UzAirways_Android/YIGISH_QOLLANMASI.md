# UzAirways — APK yig‘ish

Bu loyiha o‘yinni (`app/src/main/assets/index.html`) Android WebView ichida ishga tushiradi.
Internet ruxsati kerak emas, o‘yin to‘liq oflayn ishlaydi. Natijalar qurilmada saqlanadi.

## 1-usul: Android Studio (eng oson)
1. Android Studio'ni o‘rnating (developer.android.com/studio).
2. `File > Open` orqali shu papkani oching. Birinchi ochilishda Gradle va SDK'ni o‘zi yuklaydi.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Tayyor fayl: `app/build/outputs/apk/debug/app-debug.apk`. Uni telefonga ko‘chirib o‘rnating
   (telefonda "noma’lum manbalardan o‘rnatish"ga ruxsat bering).

## 2-usul: GitHub orqali (kompyuterga hech narsa o‘rnatmasdan)
1. Bu papkani GitHub'dagi yangi omborga yuklang.
2. `Actions > APK yig'ish > Run workflow`.
3. Tugagach, `UzAirways-debug-apk` artefaktini yuklab oling.

## 3-usul: buyruq satridan
JDK 17, Android SDK va Gradle 8.9 o‘rnatilgan bo‘lsa: `gradle assembleDebug`

## Google Play uchun
- Play Store APK emas, AAB talab qiladi: `gradle bundleRelease`.
- Release uchun o‘z kalitingizni (keystore) yarating va `app/build.gradle` ga `signingConfigs` qo‘shing.
  Kalitni yo‘qotmang va ommaga bermang.
- `targetSdk` talabi har yili o‘zgaradi. Yuklashdan oldin Play Console'dagi joriy talabni tekshiring.
- Do‘kon uchun kerak: maxfiylik siyosati, skrinshotlar, 512x512 ikona, kontent reytingi.

## Papkalar
- `app/src/main/assets/index.html` — o‘yin (kod va grafika)
- `app/src/main/java/...` — Android qobig‘i (WebView, to‘liq ekran, "Orqaga" tugmasi)
- `app/src/main/res/` — ilova ikonasi, nom, mavzu
